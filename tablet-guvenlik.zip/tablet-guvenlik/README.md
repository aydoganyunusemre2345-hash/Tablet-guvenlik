# Tablet Güvenlik Tarayıcı

Android tableti tarar: güvenlik yaması, ekran kilidi, şifreleme, USB hata ayıklama, root,
mağaza dışı uygulamalar, riskli izinler, erişilebilirlik/cihaz yöneticisi yetkileri ve APK dosyaları.
Açıkları sade Türkçeyle ve düzeltme adımıyla gösterir. Arka planda saatte bir tarar, yeni sorun varsa bildirim gönderir.

## APK nasıl alınır
1. Bu dosyaları GitHub'da yeni bir depoya yükleyin (`.github` klasörü de dahil).
2. Depoda **Actions** sekmesine girin; "APK derle" otomatik çalışır (yoksa **Run workflow**).
3. Bitince çalıştırmanın sayfasındaki **Artifacts** bölümünden `tablet-guvenlik-apk` dosyasını indirin, zip'i açın.
4. `app-debug.apk` dosyasını tablete aktarıp kurun (bilinmeyen kaynaklardan yüklemeye bir kez izin verin).
