package com.example.tabletguvenlik

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }
        setContentView(ScrollView(this).apply { addView(box) })
        box.addView(tv("Tablet Güvenlik Tarayıcı", 24f, true))
        status = tv("", 15f, false)
        box.addView(status)
        box.addView(btn("İzinleri ver") { askPermissions() })
        box.addView(btn("Şimdi tara") { scan() })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(list)

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "tarama", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<ScanWorker>(1, TimeUnit.HOURS).build()
        )
        val sp = getSharedPreferences("tarama", MODE_PRIVATE)
        if (!sp.getBoolean("asked", false)) {
            sp.edit().putBoolean("asked", true).apply()
            askPermissions()
        }
    }

    override fun onResume() { super.onResume(); scan() }

    private fun missingNotif() = Build.VERSION.SDK_INT >= 33 &&
        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED

    private fun missingStorage() = if (Build.VERSION.SDK_INT >= 30) !Environment.isExternalStorageManager()
    else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED

    private fun askPermissions() {
        if (missingNotif()) { requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1); return }
        askStorage()
    }

    private fun askStorage() {
        if (!missingStorage()) return
        if (Build.VERSION.SDK_INT >= 30)
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        else requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 2)
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, g: IntArray) {
        super.onRequestPermissionsResult(c, p, g)
        if (c == 1) askStorage() else scan()
    }

    private fun scan() {
        status.text = "Taranıyor..."
        Thread {
            val f = try { Scanner.scan(this) } catch (e: Exception) {
                listOf(Finding(1, "Tarama hatası", e.toString(), ""))
            }
            runOnUiThread { show(f) }
        }.start()
    }

    private fun show(f: List<Finding>) {
        list.removeAllViews()
        val bad = f.count { it.level >= 2 }
        status.text = "Son tarama: " + SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("tr")).format(Date()) +
            "\n" + (if (bad == 0) "Önemli bir sorun bulunmadı." else "$bad önemli sorun bulundu.") +
            "\nArka planda saatte bir otomatik taranır." +
            (if (missingNotif() || missingStorage()) "\nEksik izin var: 'İzinleri ver' düğmesine basın." else "")
        val labels = arrayOf("İyi", "Bilgi", "Orta", "Yüksek")
        val colors = intArrayOf(0xFFE2F3EA.toInt(), 0xFFE4ECF5.toInt(), 0xFFFFF1D6.toInt(), 0xFFFDE2E2.toInt())
        for (x in f) {
            val t = tv("[${labels[x.level]}] ${x.title}\n\n${x.detail}" +
                (if (x.fix.isNotBlank()) "\n\nNe yapmalı: ${x.fix}" else ""), 15f, false)
            t.setTextColor(0xFF14202B.toInt())
            t.setPadding(dp(14), dp(12), dp(14), dp(12))
            t.background = GradientDrawable().apply { setColor(colors[x.level]); cornerRadius = dp(10).toFloat() }
            t.layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(10) }
            list.addView(t)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(s: String, size: Float, bold: Boolean) = TextView(this).apply {
        text = s; textSize = size; setTextColor(Color.parseColor("#14202B"))
        if (bold) setTypeface(null, Typeface.BOLD)
    }

    private fun btn(s: String, click: () -> Unit) = Button(this).apply {
        text = s; setOnClickListener { click() }
    }
}
