package com.example.tabletguvenlik

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.work.Worker
import androidx.work.WorkerParameters

class ScanWorker(ctx: Context, p: WorkerParameters) : Worker(ctx, p) {
    override fun doWork(): Result {
        val ctx = applicationContext
        val bad = try { Scanner.scan(ctx).filter { it.level >= 2 } } catch (e: Exception) { return Result.retry() }
        val sig = bad.joinToString("|") { it.title + it.detail }.hashCode()
        val sp = ctx.getSharedPreferences("tarama", Context.MODE_PRIVATE)
        val canNotify = Build.VERSION.SDK_INT < 33 ||
            ctx.checkSelfPermission("android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED
        if (bad.isNotEmpty() && sp.getInt("sig", 0) != sig && canNotify) notify(ctx, bad)
        sp.edit().putInt("sig", sig).apply()
        return Result.success()
    }

    private fun notify(ctx: Context, bad: List<Finding>) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("guvenlik", "Güvenlik uyarıları", NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(ctx, "guvenlik")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("${bad.size} güvenlik sorunu bulundu")
            .setContentText(bad.first().title)
            .setStyle(Notification.BigTextStyle().bigText(bad.joinToString("\n") { "• " + it.title }))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(1, n)
    }
}
