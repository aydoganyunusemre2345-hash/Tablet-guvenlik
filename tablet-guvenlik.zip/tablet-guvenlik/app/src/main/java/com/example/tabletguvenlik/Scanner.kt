package com.example.tabletguvenlik

import android.Manifest
import android.app.KeyguardManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.provider.Settings
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Locale

// level: 3 = Yüksek, 2 = Orta, 1 = Bilgi, 0 = İyi
data class Finding(val level: Int, val title: String, val detail: String, val fix: String)

object Scanner {
    private val trusted = setOf(
        "com.android.vending", "com.sec.android.app.samsungapps",
        "com.huawei.appmarket", "com.amazon.venezia", "com.xiaomi.mipicks"
    )

    fun scan(ctx: Context): List<Finding> =
        (system(ctx) + apps(ctx) + files(ctx)).sortedByDescending { it.level }

    private fun isSystem(ai: ApplicationInfo) = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0

    private fun installer(pm: PackageManager, pkg: String): String? = try {
        if (Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(pkg).installingPackageName
        else @Suppress("DEPRECATION") pm.getInstallerPackageName(pkg)
    } catch (e: Exception) { null }

    private fun fromStore(pm: PackageManager, pkg: String): Boolean {
        val i = installer(pm, pkg)
        return i != null && trusted.contains(i)
    }

    // (uygulama adı, mağaza dışından mı) - sistem uygulamasıysa null
    private fun userApp(pm: PackageManager, pkg: String): Pair<String, Boolean>? = try {
        val ai = pm.getApplicationInfo(pkg, 0)
        if (isSystem(ai)) null else Pair(pm.getApplicationLabel(ai).toString(), !fromStore(pm, pkg))
    } catch (e: Exception) { null }

    private fun system(ctx: Context): List<Finding> {
        val r = mutableListOf<Finding>()
        try {
            val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(Build.VERSION.SECURITY_PATCH)
            val days = ((System.currentTimeMillis() - d!!.time) / 86400000L).toInt()
            if (days > 180) r += Finding(3, "Güvenlik yaması eski",
                "Son güvenlik yaması ${Build.VERSION.SECURITY_PATCH} tarihli ($days gün önce). Bilinen açıklar kapatılmamış olabilir.",
                "Ayarlar > Yazılım güncelleme bölümünden güncelleyin. Güncelleme çıkmıyorsa üretici desteği bitmiş olabilir; bu tabletle bankacılık işlemi yapmayın.")
            else r += Finding(0, "Güvenlik yaması güncel", "Son yama: ${Build.VERSION.SECURITY_PATCH}.", "")
        } catch (e: Exception) { }

        val km = ctx.getSystemService(KeyguardManager::class.java)
        if (!km.isDeviceSecure) r += Finding(3, "Ekran kilidi yok",
            "Tableti eline alan herkes verilerinize ulaşabilir.",
            "Ayarlar > Güvenlik > Ekran kilidi bölümünden 6 haneli PIN veya parola belirleyin.")
        else r += Finding(0, "Ekran kilidi açık", "Cihaz kilitle korunuyor.", "")

        val dpm = ctx.getSystemService(DevicePolicyManager::class.java)
        if (dpm.storageEncryptionStatus == DevicePolicyManager.ENCRYPTION_STATUS_INACTIVE)
            r += Finding(3, "Depolama şifreli değil", "Tablet çalınırsa veriler okunabilir.",
                "Ayarlar > Güvenlik > Gelişmiş > Şifreleme bölümünden şifrelemeyi açın.")

        if (Settings.Global.getInt(ctx.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1)
            r += Finding(2, "USB hata ayıklama açık",
                "Kabloyla bağlanan bir bilgisayar tabletinize geniş yetkiyle erişebilir.",
                "Ayarlar > Geliştirici seçenekleri bölümünden USB hata ayıklamayı kapatın.")

        val su = listOf("/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su")
            .any { File(it).exists() }
        if (su || Build.TAGS?.contains("test-keys") == true)
            r += Finding(3, "Cihaz root'lu olabilir",
                "Root, güvenlik korumalarını devre dışı bırakır; zararlılar tam yetki alabilir.",
                "Resmi yazılımı yeniden yükleyin veya cihazı hassas işlemlerde kullanmayın.")
        return r
    }

    private fun apps(ctx: Context): List<Finding> {
        val pm = ctx.packageManager
        val r = mutableListOf<Finding>()
        val side = mutableListOf<String>()
        val storeSensitive = mutableListOf<String>()
        val sms = setOf("android.permission.READ_SMS", "android.permission.RECEIVE_SMS", "android.permission.SEND_SMS")
        val spy = listOf("android.permission.RECORD_AUDIO", "android.permission.CAMERA", "android.permission.ACCESS_FINE_LOCATION")

        @Suppress("DEPRECATION")
        val pkgs = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
        for (p in pkgs) {
            val ai = p.applicationInfo ?: continue
            if (isSystem(ai) || p.packageName == ctx.packageName) continue
            val name = pm.getApplicationLabel(ai).toString()
            val perms = p.requestedPermissions ?: emptyArray()
            val fl = p.requestedPermissionsFlags ?: IntArray(0)
            val granted = perms.filterIndexed { i, _ ->
                i < fl.size && (fl[i] and PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0
            }.toSet()
            val why = mutableListOf<String>()
            if (granted.any { sms.contains(it) }) why += "SMS okuma/gönderme"
            if (spy.all { granted.contains(it) }) why += "mikrofon + kamera + konum"
            if (perms.contains("android.permission.SYSTEM_ALERT_WINDOW")) why += "diğer uygulamaların üstüne çizim"
            val sideloaded = !fromStore(pm, p.packageName)
            if (sideloaded && why.isNotEmpty())
                r += Finding(3, "Riskli uygulama: $name",
                    "Mağaza dışından kurulmuş ve şu yetkileri var: ${why.joinToString(", ")}.",
                    "Tanımıyorsanız Ayarlar > Uygulamalar bölümünden silin.")
            else if (sideloaded) side += name
            else if (why.isNotEmpty()) storeSensitive += "$name: ${why.joinToString(", ")}"
        }
        if (side.isNotEmpty()) r += Finding(2, "Mağaza dışından kurulan uygulamalar (${side.size})",
            side.joinToString(", "), "Tanımadığınız veya kullanmadığınız uygulamaları silin.")
        if (storeSensitive.isNotEmpty()) r += Finding(1, "Hassas izin kullanan uygulamalar",
            storeSensitive.joinToString("\n"),
            "Ayarlar > Gizlilik > İzin yöneticisi bölümünden gereksiz izinleri kapatın.")

        val acc = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        acc.split(":").mapNotNull { ComponentName.unflattenFromString(it)?.packageName }.distinct().forEach { pkg ->
            userApp(pm, pkg)?.let { (n, s) ->
                r += Finding(if (s) 3 else 2, "Erişilebilirlik izni: $n",
                    "Bu uygulama ekranınızı okuyabilir ve sizin yerinize dokunabilir. Bankacılık zararlıları bu izni kötüye kullanır.",
                    "Tanımıyorsanız Ayarlar > Erişilebilirlik bölümünden kapatıp uygulamayı silin.")
            }
        }

        val dpm = ctx.getSystemService(DevicePolicyManager::class.java)
        dpm.activeAdmins?.map { it.packageName }?.distinct()?.forEach { pkg ->
            userApp(pm, pkg)?.let { (n, s) ->
                r += Finding(if (s) 3 else 2, "Cihaz yöneticisi: $n",
                    "Bu uygulama cihaz üzerinde yönetici yetkisine sahip; silinmeye direnebilir.",
                    "Ayarlar > Güvenlik > Gelişmiş > Cihaz yönetici uygulamaları bölümünden yetkisini kaldırın.")
            }
        }
        return r
    }

    private fun sha(f: File): String = try {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { s ->
            val b = ByteArray(8192)
            while (true) { val n = s.read(b); if (n < 0) break; md.update(b, 0, n) }
        }
        md.digest().joinToString("") { "%02x".format(it) }
    } catch (e: Exception) { "okunamadı" }

    private fun files(ctx: Context): List<Finding> {
        val ok = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ctx.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        if (!ok) return listOf(Finding(1, "Dosya taraması yapılamadı",
            "Dosya erişim izni verilmediği için dosyalar taranmadı.",
            "Uygulamada 'İzinleri ver' düğmesine basıp izin verin."))

        val apks = mutableListOf<File>()
        val fake = mutableListOf<File>()
        var seen = 0
        val fakeRe = Regex(".*\\.(jpg|jpeg|png|pdf|docx?|mp4)\\.apk$")
        fun walk(d: File, depth: Int) {
            if (depth > 4 || seen > 20000) return
            for (f in d.listFiles() ?: return) {
                seen++
                if (f.isDirectory) {
                    if (!(depth == 0 && f.name == "Android")) walk(f, depth + 1)
                } else {
                    val n = f.name.lowercase()
                    if (n.endsWith(".apk")) { apks += f; if (fakeRe.matches(n)) fake += f }
                }
            }
        }
        walk(Environment.getExternalStorageDirectory(), 0)

        val r = mutableListOf<Finding>()
        if (fake.isNotEmpty()) r += Finding(3, "Sahte uzantılı APK dosyası",
            fake.joinToString("\n") { it.name },
            "Bu dosyalar resim veya belge gibi görünüp uygulama kurar. Hemen silin.")
        if (apks.isNotEmpty()) r += Finding(2, "APK dosyaları bulundu (${apks.size})",
            apks.take(15).joinToString("\n\n") { "${it.name}\nSHA-256: ${sha(it)}" },
            "Tanımadığınız APK dosyalarını silin. Kuracaksanız SHA-256 değerini virustotal.com'da aratın.")
        else r += Finding(0, "APK dosyası bulunmadı", "Dosyalarda şüpheli APK görünmüyor.", "")
        return r
    }
}
